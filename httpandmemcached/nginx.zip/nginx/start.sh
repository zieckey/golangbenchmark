
nginx/sbin/nginx 
